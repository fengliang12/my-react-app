import axios from './axios'

export * from './types/index'

export default axios